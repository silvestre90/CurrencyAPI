﻿namespace WebAPITest.Models
{
    public class Calculation
    {
        public string From { get; set; }
        public string To { get; set; }
        public long InitialAmount { get; set; }
        public decimal FinalAmount { get; set; }


    }
}
