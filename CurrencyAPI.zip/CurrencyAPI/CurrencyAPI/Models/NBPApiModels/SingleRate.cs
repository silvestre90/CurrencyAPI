﻿namespace WebAPITest.Models.NBPApiModels
{
    public class SingleRate
    {
        public string currency { get; set; }
        public string code { get; set; }
        public double mid { get; set; }
    }
}