﻿namespace WebAPITest.Models.NBPApiModels
{
    public class Rate
        {
            public string No { get; set; }
            public string effectiveDate { get; set; }
            public double mid { get; set; }
        }
    
}
